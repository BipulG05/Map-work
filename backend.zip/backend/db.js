const mongoose = require('mongoose');
const mongoUrl="mongodb://localhost:27017/personal_diary?readPreference=primary&appname=MongoDB%20Compass&ssl=false";
const connectToMongo = () =>{
    mongoose.connect(mongoUrl,()=>{
        console.log("Start the project")
    })
}
module.exports = connectToMongo;