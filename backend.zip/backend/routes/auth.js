const express = require('express');
const router = express.Router() ;
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fetchuser = require('../middleware/fetchuser')
const { body, validationResult } = require('express-validator');

const JWT_SERECT = '@Name@#BBBGroup';
//Route 1 :create user using: POST "/api/auth/createuser" .Doesnot requried auth
router.post('/createuser',[
    //authentication cheek right value of field
    body('name','Enter a valid name').isLength({ min: 6 }),
    body('email','Enter a valid email').isEmail(),
    body('password','Enter min 6 character').isLength({ min: 6 }),
    body('phoneNo','Enter a valid Phone No').isLength({ min: 10 ,max:10 })
],async (req,res)=>{
    let success = false;
    //if there are error return bad request
    const errors = validationResult(req);
    console.log(errors);

    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try{
        // cheek user already exist
        let user = await User.findOne({email:req.body.email});
        console.log(req.body.email);
        if(user){
            return res.status(400).json({success,error:'sorry a user with this email already exists'})
        }
        user = await User.findOne({email:req.body.phoneNo});
        if(user){
            return res.status(400).json({success,error:'sorry a user with this phone no already exists'})
        }
        //password encription
        const salt = await bcrypt.genSalt(10);
        const seqpassword = await bcrypt.hash(req.body.password,salt);
        console.log(seqpassword)
        
        //create user
        user = await User.create({
            name: req.body.name,
            email: req.body.email,
            password: seqpassword,
            phoneNo:req.body.phoneNo
        });
        console.log(user);
        // console.log("bipul");

        const data ={
            user:{
                id:user.id
            }
        }
        const authtoken = jwt.sign(data,JWT_SERECT);
        // console.log(authtoken);
        success = true
        res.json({success,authtoken})
        // res.json(user)
    } catch(error){
        console.log(error.massage);
        res.status(500).send("Internal Servar error occured");
    }
})

//Route 2 :Authicate a user using: POST "/api/auth/login" .Doesnot requried login

router.post('/login',[
    //authentication cheek right value of field
    
    body('email','Enter a valid email').isEmail(),
    body('password','Passwors can not be blank').exists(),
],async (req,res)=>{
    //if there are error return bad reque st

    const errors = validationResult(req);
    console.log(errors);

    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const {email,password} =req.body;

    try{
        let user = await User.findOne({email});
        if(!user){
            success = false
            return res.status(400).json({success,error:"Please try to login with correct details"});
        }
        const passwordDecript = await bcrypt.compare(password,user.password);
        if(!passwordDecript){
            success = false
            return res.status(400).json({success,error:"Please try to login with correct details"});
        }
        const data = {
            user:{
                id:user.id
            }
        }
        const authtoken = jwt.sign(data,JWT_SERECT);
        success = true
        res.json({success,authtoken})
    }catch(error){
        console.log(error.massage);
        res.status(500).send("Internal Servar error occured");
    }

})

//Route 2 :AGet loggedin user details uusing: POST "/api/auth/getuser" login requred
router.post('/getuser',fetchuser,async (req,res)=>{
    try{
        userId=req.user.id;
        const user = await User.findById(userId).select("-password");
        res.send(user)
    }catch(error){
        console.log(error.massage);
        res.status(500).send("Internal servar error")
    }
})

module.exports = router