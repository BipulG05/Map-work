const express = require('express');
const router = express.Router() ;
const fetchuser = require('../middleware/fetchuser');
const Notes = require('../models/Notes');
const mongoose = require('mongoose');
const {Schema} = mongoose;
const { body, validationResult } = require('express-validator');
const { NotBeforeError } = require('jsonwebtoken');



// Routes 1:Get all the notes using : /api/notes/fetchnotes , login required
router.get('/fetchnotes',fetchuser,async (req,res)=>{
    // //console.log({user:req.user.id})
    try{
        const notes = await  Notes.find({user:req.user.id})
        //console.log(notes)
        res.json(notes)
    }catch(error){
        //console.log(error.massage);
        res.status(500).send("Internal Servar error occured");
    }
    
})

// Routes 2:Post all the notes using : /api/notes/addnote , login required
router.post('/addnote',fetchuser,[
    //authentication cheek right value of field
    body('title','Enter a valid title').isLength({ min: 3 }),
    body('description','Enter a valid description').isLength({ min: 3 }),
],async (req,res)=>{
    try{
        //if there are error return bad request
        const {title,description,tag} = req.body;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const note = new Notes({
            title,description,tag,user:req.user.id
        })
        // //console.log(note)
        const saveNote = await note.save();
        res.json(saveNote)
    }catch(error){
        //console.log(error.massage);
        res.status(500).send("Internal Servar error occured");
    }

})
// Routes 3:put all the notes using : /api/notes/updatenote/:id , login required
router.put('/updatenote/:id',fetchuser,[
    //authentication cheek right value of field
    body('title','Enter a valid title').isLength({ min: 3 }),
    body('description','Enter a valid description').isLength({ min: 3 })
],async (req,res)=>{
    try{
        //if there are error return bad request
        const {title,description,tag} = req.body;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        
        const newNote = {}
        
        // //console.log(note)
        if(title){newNote.title = title};
        if(description){newNote.description = description};
        if(tag){newNote.tag = tag};
        
        //find the node to updated
        let note = await Notes.findById(req.params.id);
        if(!note){res.status(404).send("Not found")}
        // //console.log(req.params.id)
        // //console.log(note.user)
        if(note.user.toString()!== req.user.id){
            return res.status(401).send("Not Alllowed");
        }
        // //console.log(newNote);
        // //console.log(req.params.id);
        note = await Notes.findByIdAndUpdate(req.params.id,{$set: newNote},{new:true});
        res.json({note})

    }catch(error){
        //console.log(error.massage);
        res.status(500).send("Internal Servar error occured");
    }

})

// Routes 4:delete all the notes using : /api/notes/deletenote/id , login required
router.delete('/deletenote/:id',fetchuser,async (req,res)=>{
    try{
        //if there are error return bad request
        let note = await Notes.findById(req.params.id);
        if(!note){res.status(404).send("Not found")}
        //Aollow deletetion then delete
        if(note.user.toString()!== req.user.id){
            return res.status(401).send("Not Alllowed");
        }
        note = await Notes.findByIdAndDelete(req.params.id);
        res.json({"Success":"Note has been deleted",note:note})

    }catch(error){
        //console.log(error.massage);
        res.status(500).send("Internal Servar error occured");
    }

})




module.exports = router